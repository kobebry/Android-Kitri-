package com.exam.andex01.widgetmenu;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class WidgetActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.select_ex04);
    }
}
